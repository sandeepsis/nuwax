/*
SQLyog Community Edition- MySQL GUI v7.11 
MySQL - 5.6.17 : Database - nuwax
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`nuwax` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `nuwax`;

/*Table structure for table `bookings` */

DROP TABLE IF EXISTS `bookings`;

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerid` int(11) DEFAULT NULL,
  `serviceid` int(11) DEFAULT NULL,
  `staffid` int(11) DEFAULT NULL,
  `actualprice` int(11) DEFAULT NULL,
  `offerprice` int(11) DEFAULT NULL,
  `servicedate` datetime DEFAULT NULL,
  `servicetime` varchar(255) DEFAULT NULL,
  `totalprice` int(11) DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL COMMENT '1=New,2=Confirmed,3=Cancelled,4=Absent,5=Complete',
  `is_deleted` tinyint(2) DEFAULT NULL COMMENT '0=not delete 1=deleted',
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
