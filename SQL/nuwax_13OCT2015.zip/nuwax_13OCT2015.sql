/*
SQLyog Community Edition- MySQL GUI v7.11 
MySQL - 5.6.17 : Database - nuwax
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


USE `nuwax`;

/*Table structure for table `bookingservices` */

alter table bookings drop column serviceid
alter table bookings drop column actualprice
alter table bookings drop column offerprice

DROP TABLE IF EXISTS `bookingservices`;

CREATE TABLE `bookingservices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookingid` int(11) DEFAULT NULL,
  `serviceid` int(11) DEFAULT NULL,
  `actualprice` int(11) DEFAULT NULL,
  `offerprice` int(11) DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL COMMENT '0=approve,1=cancel',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Table structure for table `creditmanagement` */

DROP TABLE IF EXISTS `creditmanagement`;

CREATE TABLE `creditmanagement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerid` int(11) DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `bookingid` int(11) DEFAULT NULL,
  `credit` int(11) DEFAULT NULL,
  `credittype` tinyint(2) DEFAULT NULL COMMENT '0=add,1=deduct',
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
