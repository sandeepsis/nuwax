/*
SQLyog Community Edition- MySQL GUI v7.11 
MySQL - 5.6.17 : Database - nuwax
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`nuwax` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `nuwax`;

/*Table structure for table `action_recorder` */

DROP TABLE IF EXISTS `action_recorder`;

CREATE TABLE `action_recorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `success` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_action_recorder_identifier` (`identifier`),
  KEY `idx_action_recorder_date_added` (`date_added`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `action_recorder` */

insert  into `action_recorder`(`id`,`user_name`,`identifier`,`success`,`date_added`) values (75,'','fe80::f468:a052:a95:248b','0','2015-10-02 12:29:22'),(76,'','fe80::f468:a052:a95:248b','0','2015-10-02 12:29:27'),(77,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 12:29:36'),(78,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 13:08:58'),(79,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 13:24:10'),(80,'admin','192.168.0.4','1','2015-10-02 13:29:26'),(81,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 13:54:26'),(82,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 14:05:49'),(83,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 14:16:25'),(84,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 14:19:39'),(85,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 17:51:47'),(86,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 17:54:31'),(87,'admin','fe80::f468:a052:a95:248b','1','2015-10-03 10:25:22'),(88,'admin','fe80::f468:a052:a95:248b','1','2015-10-03 10:29:00'),(89,'admin','fe80::f468:a052:a95:248b','1','2015-10-03 10:31:20'),(90,'admin','fe80::f468:a052:a95:248b','1','2015-10-03 10:32:38'),(91,'admin','fe80::f468:a052:a95:248b','1','2015-10-03 16:10:08'),(92,'admin','fe80::f468:a052:a95:248b','1','2015-10-05 13:19:25'),(93,'admin','fe80::f468:a052:a95:248b','1','2015-10-06 11:40:24'),(94,'admin','fe80::f468:a052:a95:248b','1','2015-10-06 16:35:33'),(95,'admin','fe80::f468:a052:a95:248b','1','2015-10-07 10:23:37'),(96,'admin','fe80::f468:a052:a95:248b','1','2015-10-07 15:54:28'),(97,'admin','fe80::f468:a052:a95:248b','1','2015-10-08 10:52:39'),(98,'admin','fe80::f468:a052:a95:248b','1','2015-10-08 16:41:45');

/*Table structure for table `admins` */

DROP TABLE IF EXISTS `admins`;

CREATE TABLE `admins` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `status` enum('super admin','admin') NOT NULL DEFAULT 'admin',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `admins` */

insert  into `admins`(`id`,`username`,`password`,`last_name`,`first_name`,`email`,`status`) values (1,'admin','e10adc3949ba59abbe56e057f20f883e','Admin','Nuwax','admin@nuwax.com','super admin');

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `contactno` varchar(255) DEFAULT NULL,
  `address` text,
  `studentcardno` varchar(255) DEFAULT NULL,
  `studentcardvalidity` datetime DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL COMMENT '0=active,1=inactive',
  `remark` text,
  `credit` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL COMMENT '0=notdeleted,1=deleted',
  `registerdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

insert  into `customer`(`id`,`name`,`email`,`password`,`contactno`,`address`,`studentcardno`,`studentcardvalidity`,`status`,`remark`,`credit`,`is_deleted`,`registerdate`) values (1,'test','test@asd.com','d41d8cd98f00b204e9800998ecf8427e','7657886','jhg','jh',NULL,0,'hj','g',0,'2015-10-07 23:35:35'),(2,'test','test@asd.ghj','4297f44b13955235245b2497399d7a93','123','yt','y','2015-10-31 00:00:00',0,'y','y',0,'2015-10-08 13:27:24'),(3,'asd','asd@asd.ghj','e10adc3949ba59abbe56e057f20f883e','123','w','w',NULL,0,'w','w',0,'2015-10-08 13:52:09');

/*Table structure for table `customertoken` */

DROP TABLE IF EXISTS `customertoken`;

CREATE TABLE `customertoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerid` int(11) DEFAULT NULL,
  `token` text,
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `customertoken` */

insert  into `customertoken`(`id`,`customerid`,`token`,`date_added`) values (1,1,'a5c0a995115021ab8603f311e05cc09d','2015-10-07 23:35:35'),(2,2,'398bdcecab24b819de2d99cc0202bead','2015-10-08 13:27:24'),(3,3,'95863b052260c0566c53dab10b8a9bf6','2015-10-08 13:52:09');

/*Table structure for table `data_log` */

DROP TABLE IF EXISTS `data_log`;

CREATE TABLE `data_log` (
  `logID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `actionDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `recordID` int(11) NOT NULL,
  `siteSection` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userLevel` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`logID`)
) ENGINE=InnoDB AUTO_INCREMENT=468 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `data_log` */

insert  into `data_log`(`logID`,`userID`,`actionDateTime`,`action`,`recordID`,`siteSection`,`ip`,`userLevel`) values (251,1,'2015-10-02 13:05:15','Edited',1,'Admin Management','fe80::f468:a052:a95:','super admin'),(252,1,'2015-10-02 14:24:39','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(253,1,'2015-10-02 14:25:18','Edited',1,'Admin Management','fe80::f468:a052:a95:','super admin'),(254,1,'2015-10-02 15:44:42','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(255,1,'2015-10-02 16:39:16','Added',1,'Customer Management','fe80::f468:a052:a95:','super admin'),(256,1,'2015-10-02 16:42:39','Added',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(257,1,'2015-10-02 17:15:43','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(258,1,'2015-10-02 17:15:58','Edited',1,'Customer Management','fe80::f468:a052:a95:','super admin'),(259,1,'2015-10-02 17:16:15','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(260,1,'2015-10-02 17:17:03','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(261,1,'2015-10-02 17:17:14','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(262,1,'2015-10-02 17:17:59','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(263,1,'2015-10-02 17:18:05','Edited',1,'Customer Management','fe80::f468:a052:a95:','super admin'),(264,1,'2015-10-02 17:32:00','Added',3,'Customer Management','fe80::f468:a052:a95:','super admin'),(265,1,'2015-10-02 17:33:44','Added',4,'Customer Management','fe80::f468:a052:a95:','super admin'),(266,1,'2015-10-02 17:38:26','Deleted',3,'Customer Management','fe80::f468:a052:a95:','super admin'),(267,1,'2015-10-02 17:41:29','Edited',4,'Customer Management','fe80::f468:a052:a95:','super admin'),(268,1,'2015-10-02 17:41:38','Deleted',4,'Customer Management','fe80::f468:a052:a95:','super admin'),(269,1,'2015-10-02 17:41:38','Deleted',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(270,1,'2015-10-02 17:41:38','Deleted',1,'Customer Management','fe80::f468:a052:a95:','super admin'),(271,1,'2015-10-02 17:47:55','Changed',4,'Customer Password','fe80::f468:a052:a95:','super admin'),(272,1,'2015-10-02 17:52:28','Added',5,'Customer Management','fe80::f468:a052:a95:','super admin'),(273,1,'2015-10-02 17:52:42','Added',6,'Customer Management','fe80::f468:a052:a95:','super admin'),(274,1,'2015-10-02 17:52:53','Added',7,'Customer Management','fe80::f468:a052:a95:','super admin'),(275,1,'2015-10-02 17:53:06','Added',8,'Customer Management','fe80::f468:a052:a95:','super admin'),(276,1,'2015-10-02 17:53:18','Added',9,'Customer Management','fe80::f468:a052:a95:','super admin'),(277,1,'2015-10-02 17:53:30','Added',10,'Customer Management','fe80::f468:a052:a95:','super admin'),(278,1,'2015-10-02 17:53:41','Added',11,'Customer Management','fe80::f468:a052:a95:','super admin'),(279,1,'2015-10-02 18:03:17','Added',1,'Customer Management','fe80::f468:a052:a95:','super admin'),(280,1,'2015-10-02 18:19:02','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(281,1,'2015-10-02 19:08:50','Deleted',14,'Menu Management','fe80::f468:a052:a95:','super admin'),(282,1,'2015-10-02 19:08:50','Deleted',15,'Menu Management','fe80::f468:a052:a95:','super admin'),(283,1,'2015-10-02 19:08:50','Deleted',16,'Menu Management','fe80::f468:a052:a95:','super admin'),(284,1,'2015-10-03 16:25:28','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(285,1,'2015-10-03 16:27:22','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(286,1,'2015-10-03 16:28:09','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(287,1,'2015-10-03 16:28:44','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(288,1,'2015-10-03 16:33:40','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(289,1,'2015-10-03 17:08:39','Edited',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(290,1,'2015-10-03 17:09:13','Edited',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(291,1,'2015-10-03 17:22:36','Edited',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(292,1,'2015-10-03 17:29:17','Edited',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(293,1,'2015-10-03 17:29:21','Edited',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(294,1,'2015-10-03 17:29:41','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(295,1,'2015-10-03 17:31:17','Edited',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(296,1,'2015-10-03 17:31:33','Edited',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(297,1,'2015-10-03 17:31:39','Edited',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(298,1,'2015-10-03 17:31:44','Edited',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(299,1,'2015-10-03 17:31:51','Deleted',1,'Service category Management','fe80::f468:a052:a95:','super admin'),(300,1,'2015-10-03 17:32:35','Deleted',3,'Service category Management','fe80::f468:a052:a95:','super admin'),(301,1,'2015-10-03 17:32:35','Deleted',2,'Service category Management','fe80::f468:a052:a95:','super admin'),(302,1,'2015-10-03 17:32:53','Deleted',3,'Service category Management','fe80::f468:a052:a95:','super admin'),(303,1,'2015-10-03 17:32:58','Deleted',2,'Service category Management','fe80::f468:a052:a95:','super admin'),(304,1,'2015-10-03 17:32:58','Deleted',1,'Service category Management','fe80::f468:a052:a95:','super admin'),(305,1,'2015-10-03 17:33:34','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(306,1,'2015-10-03 17:33:41','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(307,1,'2015-10-03 17:33:48','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(308,1,'2015-10-03 17:33:56','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(309,1,'2015-10-03 17:34:08','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(310,1,'2015-10-03 17:34:17','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(311,1,'2015-10-03 17:34:24','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(312,1,'2015-10-03 17:34:32','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(313,1,'2015-10-03 17:34:49','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(314,1,'2015-10-03 17:35:14','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(315,1,'2015-10-03 17:53:50','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(316,1,'2015-10-03 17:53:57','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(317,1,'2015-10-03 18:30:48','Deleted',2,'Service category Management','fe80::f468:a052:a95:','super admin'),(318,1,'2015-10-03 18:31:03','Deleted',1,'Service category Management','fe80::f468:a052:a95:','super admin'),(319,1,'2015-10-03 18:31:29','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(320,1,'2015-10-03 18:31:37','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(321,1,'2015-10-03 18:31:43','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(322,1,'2015-10-03 18:31:47','Deleted',4,'Service category Management','fe80::f468:a052:a95:','super admin'),(323,1,'2015-10-03 18:37:55','Deleted',0,'Service category Management','fe80::f468:a052:a95:','super admin'),(324,1,'2015-10-03 18:38:25','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(325,1,'2015-10-05 15:06:36','Added',1,'Service Management','fe80::f468:a052:a95:','super admin'),(326,1,'2015-10-05 15:08:20','Added',2,'Service Management','fe80::f468:a052:a95:','super admin'),(327,1,'2015-10-05 15:31:38','Added',3,'Service Management','fe80::f468:a052:a95:','super admin'),(328,1,'2015-10-05 15:57:43','Edited',3,'Service Management','fe80::f468:a052:a95:','super admin'),(329,1,'2015-10-05 15:57:52','Edited',3,'Service Management','fe80::f468:a052:a95:','super admin'),(330,1,'2015-10-05 15:58:40','Added',0,'Service Category Management','fe80::f468:a052:a95:','super admin'),(331,1,'2015-10-05 15:58:55','Edited',2,'Service Management','fe80::f468:a052:a95:','super admin'),(332,1,'2015-10-05 15:59:54','Edited',2,'Service Management','fe80::f468:a052:a95:','super admin'),(333,1,'2015-10-05 16:00:24','Deleted',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(334,1,'2015-10-05 16:01:22','Deleted',2,'Service Management','fe80::f468:a052:a95:','super admin'),(335,1,'2015-10-05 16:01:35','Deleted',3,'Service Management','fe80::f468:a052:a95:','super admin'),(336,1,'2015-10-05 16:01:35','Deleted',1,'Service Management','fe80::f468:a052:a95:','super admin'),(337,1,'2015-10-05 16:19:48','Added',13,'Menu Management','fe80::f468:a052:a95:','super admin'),(338,1,'2015-10-05 16:25:25','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(339,1,'2015-10-05 16:26:04','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(340,1,'2015-10-05 17:32:04','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(341,1,'2015-10-05 17:34:14','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(342,1,'2015-10-05 17:38:40','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(343,1,'2015-10-05 18:05:46','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(344,1,'2015-10-05 18:05:58','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(345,1,'2015-10-05 18:06:22','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(346,1,'2015-10-05 18:06:46','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(347,1,'2015-10-05 18:07:28','Deleted',1,'Staff Management','fe80::f468:a052:a95:','super admin'),(348,1,'2015-10-05 18:07:50','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(349,1,'2015-10-05 18:07:56','Deleted',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(350,1,'2015-10-05 18:08:40','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(351,1,'2015-10-05 18:31:21','Added',14,'Menu Management','fe80::f468:a052:a95:','super admin'),(352,1,'2015-10-05 18:57:37','Edited',2,'Service Management','fe80::f468:a052:a95:','super admin'),(353,1,'2015-10-05 18:58:04','Edited',1,'Service Management','fe80::f468:a052:a95:','super admin'),(354,1,'2015-10-05 19:29:45','Added',1,'Package Management','fe80::f468:a052:a95:','super admin'),(355,1,'2015-10-05 19:30:24','Added',2,'Package Management','fe80::f468:a052:a95:','super admin'),(356,1,'2015-10-05 19:49:53','Added',3,'Package Management','fe80::f468:a052:a95:','super admin'),(357,1,'2015-10-05 19:53:26','Edited',3,'Package Management','fe80::f468:a052:a95:','super admin'),(358,1,'2015-10-05 19:53:56','Edited',3,'Package Management','fe80::f468:a052:a95:','super admin'),(359,1,'2015-10-05 19:54:02','Edited',3,'Package Management','fe80::f468:a052:a95:','super admin'),(360,1,'2015-10-05 19:55:12','Deleted',1,'Package Management','fe80::f468:a052:a95:','super admin'),(361,1,'2015-10-05 20:02:34','Deleted',3,'Package Management','fe80::f468:a052:a95:','super admin'),(362,1,'2015-10-05 20:02:34','Deleted',2,'Package Management','fe80::f468:a052:a95:','super admin'),(363,1,'2015-10-05 20:28:37','Edited',1,'Package Management','fe80::f468:a052:a95:','super admin'),(364,1,'2015-10-06 20:00:30','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(365,1,'2015-10-06 20:01:28','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(366,1,'2015-10-06 20:02:21','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(367,1,'2015-10-06 20:05:38','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(368,1,'2015-10-06 20:08:57','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(369,1,'2015-10-06 21:03:17','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(370,1,'2015-10-06 21:03:57','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(371,1,'2015-10-07 11:18:09','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(372,1,'2015-10-07 11:38:14','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(373,1,'2015-10-07 12:06:59','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(374,1,'2015-10-07 12:07:31','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(375,1,'2015-10-07 12:10:08','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(376,1,'2015-10-07 12:10:27','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(377,1,'2015-10-07 12:11:29','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(378,1,'2015-10-07 12:11:57','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(379,1,'2015-10-07 12:12:32','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(380,1,'2015-10-07 12:12:45','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(381,1,'2015-10-07 12:13:44','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(382,1,'2015-10-07 12:14:57','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(383,1,'2015-10-07 12:15:13','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(384,1,'2015-10-07 12:15:50','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(385,1,'2015-10-07 12:17:22','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(386,1,'2015-10-07 12:17:59','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(387,1,'2015-10-07 12:18:28','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(388,1,'2015-10-07 12:18:51','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(389,1,'2015-10-07 12:19:09','Deleted',10,'Staff Management','fe80::f468:a052:a95:','super admin'),(390,1,'2015-10-07 12:24:57','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(391,1,'2015-10-07 12:25:19','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(392,1,'2015-10-07 16:22:20','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(393,1,'2015-10-07 16:33:54','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(394,1,'2015-10-07 17:09:10','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(395,1,'2015-10-07 17:18:27','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(396,1,'2015-10-07 17:25:28','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(397,1,'2015-10-07 17:25:38','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(398,1,'2015-10-07 18:13:15','Added',8,'Service Management','fe80::f468:a052:a95:','super admin'),(399,1,'2015-10-07 18:14:13','Added',9,'Service Management','fe80::f468:a052:a95:','super admin'),(400,1,'2015-10-07 18:49:44','Edited',9,'Service Management','fe80::f468:a052:a95:','super admin'),(401,1,'2015-10-07 18:54:23','Edited',9,'Service Management','fe80::f468:a052:a95:','super admin'),(402,1,'2015-10-07 18:55:12','Edited',9,'Service Management','fe80::f468:a052:a95:','super admin'),(403,1,'2015-10-07 18:55:51','Edited',9,'Service Management','fe80::f468:a052:a95:','super admin'),(404,1,'2015-10-07 18:57:08','Edited',9,'Service Management','fe80::f468:a052:a95:','super admin'),(405,1,'2015-10-07 19:00:18','Edited',9,'Service Management','fe80::f468:a052:a95:','super admin'),(406,1,'2015-10-07 19:01:01','Edited',9,'Service Management','fe80::f468:a052:a95:','super admin'),(407,1,'2015-10-07 19:09:27','Edited',9,'Service Management','fe80::f468:a052:a95:','super admin'),(408,1,'2015-10-07 19:10:12','Edited',9,'Service Management','fe80::f468:a052:a95:','super admin'),(409,1,'2015-10-07 19:28:05','Edited',9,'Service Management','fe80::f468:a052:a95:','super admin'),(410,1,'2015-10-07 19:28:18','Edited',9,'Service Management','fe80::f468:a052:a95:','super admin'),(411,1,'2015-10-07 19:48:14','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(412,1,'2015-10-07 20:29:33','Added',4,'Customer Management','fe80::f468:a052:a95:','super admin'),(413,1,'2015-10-07 20:32:57','Added',5,'Customer Management','fe80::f468:a052:a95:','super admin'),(414,1,'2015-10-07 21:05:40','Added',1,'Customer Management','fe80::f468:a052:a95:','super admin'),(415,1,'2015-10-07 21:19:56','Changed',1,'Customer Password','fe80::f468:a052:a95:','super admin'),(416,1,'2015-10-07 21:31:28','Added',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(417,1,'2015-10-07 21:46:08','Added',1,'Service Management','fe80::f468:a052:a95:','super admin'),(418,1,'2015-10-07 21:46:58','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(419,1,'2015-10-08 10:57:31','Added',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(420,1,'2015-10-08 11:22:14','Added',3,'Customer Management','fe80::f468:a052:a95:','super admin'),(421,1,'2015-10-08 13:38:42','Added',1,'Package Allocation','fe80::f468:a052:a95:','super admin'),(422,1,'2015-10-08 13:40:54','Added',2,'Package Allocation','fe80::f468:a052:a95:','super admin'),(423,1,'2015-10-08 16:54:26','Added',1,'Package Allocation','fe80::f468:a052:a95:','super admin'),(424,1,'2015-10-08 16:54:42','Added',2,'Package Allocation','fe80::f468:a052:a95:','super admin'),(425,1,'2015-10-08 16:58:26','Added',3,'Package Allocation','fe80::f468:a052:a95:','super admin'),(426,1,'2015-10-08 16:58:36','Added',4,'Package Allocation','fe80::f468:a052:a95:','super admin'),(427,1,'2015-10-08 17:00:41','Added',5,'Package Allocation','fe80::f468:a052:a95:','super admin'),(428,1,'2015-10-08 17:01:53','Added',6,'Package Allocation','fe80::f468:a052:a95:','super admin'),(429,1,'2015-10-08 17:02:24','Added',7,'Package Allocation','fe80::f468:a052:a95:','super admin'),(430,1,'2015-10-08 17:05:24','Added',8,'Package Allocation','fe80::f468:a052:a95:','super admin'),(431,1,'2015-10-08 17:05:56','Added',9,'Package Allocation','fe80::f468:a052:a95:','super admin'),(432,1,'2015-10-08 17:30:17','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(433,1,'2015-10-08 17:31:05','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(434,1,'2015-10-08 17:31:16','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(435,1,'2015-10-08 17:42:01','Added',15,'Menu Management','fe80::f468:a052:a95:','super admin'),(436,1,'2015-10-08 18:13:12','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(437,1,'2015-10-08 19:06:12','Added',1,'Stock Management','fe80::f468:a052:a95:','super admin'),(438,1,'2015-10-08 19:13:10','Added',2,'Stock Management','fe80::f468:a052:a95:','super admin'),(439,1,'2015-10-08 19:25:31','Added',3,'Stock Management','fe80::f468:a052:a95:','super admin'),(440,1,'2015-10-08 19:30:22','Edited',3,'Stock Management','fe80::f468:a052:a95:','super admin'),(441,1,'2015-10-08 19:30:58','Edited',3,'Stock Management','fe80::f468:a052:a95:','super admin'),(442,1,'2015-10-08 19:31:30','Edited',3,'Stock Management','fe80::f468:a052:a95:','super admin'),(443,1,'2015-10-08 19:33:13','Deleted',3,'Stock Management','fe80::f468:a052:a95:','super admin'),(444,1,'2015-10-08 19:34:17','Deleted',2,'Stock Management','fe80::f468:a052:a95:','super admin'),(445,1,'2015-10-08 19:34:17','Deleted',1,'Stock Management','fe80::f468:a052:a95:','super admin'),(446,1,'2015-10-08 19:44:42','Added',4,'Package Management','fe80::f468:a052:a95:','super admin'),(447,1,'2015-10-08 19:45:44','Edited',4,'Package Management','fe80::f468:a052:a95:','super admin'),(448,1,'2015-10-08 19:45:50','Edited',4,'Package Management','fe80::f468:a052:a95:','super admin'),(449,1,'2015-10-08 19:53:15','Added',16,'Menu Management','fe80::f468:a052:a95:','super admin'),(450,1,'2015-10-08 20:02:53','Added',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(451,1,'2015-10-08 20:03:59','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(452,1,'2015-10-08 20:04:06','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(453,1,'2015-10-08 20:04:14','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(454,1,'2015-10-08 20:17:34','Added',2,'Service Management','fe80::f468:a052:a95:','super admin'),(455,1,'2015-10-08 20:24:09','Edited',2,'Service Management','fe80::f468:a052:a95:','super admin'),(456,1,'2015-10-08 20:24:28','Edited',2,'Service Management','fe80::f468:a052:a95:','super admin'),(457,1,'2015-10-08 20:25:21','Added',3,'Service Management','fe80::f468:a052:a95:','super admin'),(458,1,'2015-10-08 20:31:44','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(459,1,'2015-10-08 20:31:56','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(460,1,'2015-10-08 20:32:03','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(461,1,'2015-10-08 20:32:13','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(462,1,'2015-10-08 20:32:23','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(463,1,'2015-10-08 20:33:52','Edited',1,'Service Management','fe80::f468:a052:a95:','super admin'),(464,1,'2015-10-08 20:34:07','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(465,1,'2015-10-08 20:34:17','Edited',0,'Staff Management','fe80::f468:a052:a95:','super admin'),(466,1,'2015-10-08 20:36:52','Edited',3,'Stock Management','fe80::f468:a052:a95:','super admin'),(467,1,'2015-10-08 20:37:45','Edited',2,'Stock Management','fe80::f468:a052:a95:','super admin');

/*Table structure for table `menu` */

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `page_name` varchar(255) NOT NULL DEFAULT '',
  `is_menu_group` tinyint(1) NOT NULL DEFAULT '0',
  `is_removable` tinyint(1) NOT NULL DEFAULT '0',
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order_index` tinyint(3) NOT NULL DEFAULT '0',
  `icon` varchar(30) DEFAULT NULL,
  `is_dashboard_icon` tinyint(1) DEFAULT '1',
  `is_menu_item` tinyint(1) NOT NULL DEFAULT '1',
  `file_type_id` tinyint(3) NOT NULL DEFAULT '2',
  `access_roles` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'super admin',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `is_menu_name` (`is_menu_group`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `menu` */

insert  into `menu`(`id`,`name`,`page_name`,`is_menu_group`,`is_removable`,`is_hidden`,`parent_id`,`order_index`,`icon`,`is_dashboard_icon`,`is_menu_item`,`file_type_id`,`access_roles`) values (1,'General','',1,0,0,0,0,'general.png',1,1,2,'super admin,Level4'),(2,'Account Manager','',1,0,0,0,1,NULL,1,1,2,'super admin'),(3,'Menu Manager','menu_manager/index.php',0,0,0,1,1,'general.png',1,1,2,'super admin'),(5,'Administrators','admins/index.php',0,0,0,2,0,'admin.png',1,1,2,'super admin'),(10,'Master Forms','',1,0,0,0,2,NULL,1,1,2,'super admin'),(11,'Customers','customers/index',0,0,0,10,1,'xyzer',1,1,2,'super admin'),(12,'Services','services/index',0,0,0,10,3,'xyzer',1,1,2,'super admin'),(13,'Staff Members','staff/index',0,0,0,10,4,'xyzer',1,1,2,'super admin'),(14,'Packages','packages/index',0,0,0,10,5,'xyzer',1,1,2,'super admin'),(15,'Stock Management','stock/index',0,0,0,10,6,' xyzer',1,1,2,'super admin'),(16,'Manage Category','servicecategories',0,0,0,10,2,'xyzer',1,1,2,'super admin');

/*Table structure for table `package` */

DROP TABLE IF EXISTS `package`;

CREATE TABLE `package` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `creditprovided` int(11) DEFAULT NULL,
  `serviceapplicable` varchar(255) DEFAULT NULL,
  `servicediscount` int(5) DEFAULT NULL,
  `productdiscount` int(5) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercent` int(5) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `package` */

insert  into `package`(`id`,`name`,`cost`,`creditprovided`,`serviceapplicable`,`servicediscount`,`productdiscount`,`taxname`,`taxpercent`,`is_deleted`,`date_added`) values (1,'Silver',2500,50,'3',10,7,'service',10,0,'2015-10-05 21:59:45'),(2,'Gold',2000,100,'3,2,1',2,3,'service',10,0,'2015-10-05 22:00:24'),(3,'Platinum',5000,200,'3,2,1',12,6,'serivice',20,0,'2015-10-05 22:19:53'),(4,'test',100,1000,'1',100,0,'service',6,0,'2015-10-08 22:14:42');

/*Table structure for table `packageallocation` */

DROP TABLE IF EXISTS `packageallocation`;

CREATE TABLE `packageallocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerid` int(11) DEFAULT NULL,
  `packageid` int(11) DEFAULT NULL,
  `payment_type` tinyint(2) DEFAULT NULL COMMENT '0=cash,1=cheque,2=other',
  `amount` int(11) DEFAULT NULL,
  `bank` varchar(255) DEFAULT NULL,
  `instrumentname` varchar(255) DEFAULT NULL,
  `instrumentno` int(15) DEFAULT NULL,
  `chequeamount` int(11) DEFAULT NULL,
  `chequedate` date DEFAULT NULL,
  `allocationdate` datetime DEFAULT NULL,
  `remark` text,
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `packageallocation` */

/*Table structure for table `servicecategory` */

DROP TABLE IF EXISTS `servicecategory`;

CREATE TABLE `servicecategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(255) DEFAULT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `remark` text,
  `is_deleted` tinyint(2) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `servicecategory` */

insert  into `servicecategory`(`id`,`categoryname`,`description`,`image`,`remark`,`is_deleted`,`date_added`) values (1,'test','test','1443877705.jpg','',0,'2015-10-03 21:08:25'),(2,'Makeup','makeup','1444040920.jpg','test',0,'2015-10-05 18:28:40');

/*Table structure for table `services` */

DROP TABLE IF EXISTS `services`;

CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `servicecatid` int(11) DEFAULT NULL,
  `servicename` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `headtherapistprice` int(11) DEFAULT NULL,
  `seniortherapistprice` int(11) DEFAULT NULL,
  `servicetime` varchar(255) DEFAULT NULL,
  `description` text,
  `taxname` varchar(255) DEFAULT NULL,
  `taxapplicable` int(5) DEFAULT NULL,
  `tax_underpackage` tinyint(2) DEFAULT NULL COMMENT '0=yes,1=no',
  `is_deleted` tinyint(2) DEFAULT NULL COMMENT '0=not deleted,1=deleted',
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `services` */

insert  into `services`(`id`,`servicecatid`,`servicename`,`price`,`headtherapistprice`,`seniortherapistprice`,`servicetime`,`description`,`taxname`,`taxapplicable`,`tax_underpackage`,`is_deleted`,`date_added`) values (1,2,'test',1000,0,1500,'60','test','service',10,0,0,'2015-10-08 00:16:08'),(2,2,'Clean Up',200,600,500,'25','test','service',10,0,0,'2015-10-08 22:47:34'),(3,1,'Hair style',300,1000,600,'120','test','service',10,0,0,'2015-10-08 22:55:20');

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `contactno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `staff` */

insert  into `staff`(`id`,`name`,`image`,`contactno`,`email`,`address`,`is_deleted`,`date_added`) values (1,'user1','1444234618.jpg','123123','abc@ads.com','test',0,'2015-10-08 00:16:58'),(2,'test','1444314773.jpg','123','test@test.com','teste',0,'2015-10-08 22:32:53');

/*Table structure for table `stafflevel` */

DROP TABLE IF EXISTS `stafflevel`;

CREATE TABLE `stafflevel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `stafflevel` */

insert  into `stafflevel`(`id`,`name`,`is_deleted`) values (1,'Head Therapist',0),(2,'Senior Therapist',0);

/*Table structure for table `staffservices` */

DROP TABLE IF EXISTS `staffservices`;

CREATE TABLE `staffservices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) DEFAULT NULL,
  `serviceid` int(11) DEFAULT NULL,
  `stafflevelid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `staffservices` */

insert  into `staffservices`(`id`,`staffid`,`serviceid`,`stafflevelid`) values (1,1,1,1),(2,2,1,1),(3,2,1,2);

/*Table structure for table `stockmanagement` */

DROP TABLE IF EXISTS `stockmanagement`;

CREATE TABLE `stockmanagement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(2) DEFAULT NULL COMMENT '0=for sale,1=stop sell',
  `categoryid` int(11) DEFAULT NULL,
  `productname` varchar(255) DEFAULT NULL,
  `skucode` varchar(255) DEFAULT NULL,
  `barcode` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `unit` int(11) DEFAULT NULL,
  `volume` int(11) DEFAULT NULL,
  `costprice` int(11) DEFAULT NULL,
  `sellingprice` int(11) DEFAULT NULL,
  `description` text,
  `is_deleted` tinyint(2) DEFAULT NULL COMMENT '0=notdelete,1=deleted',
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `stockmanagement` */

insert  into `stockmanagement`(`id`,`status`,`categoryid`,`productname`,`skucode`,`barcode`,`model`,`unit`,`volume`,`costprice`,`sellingprice`,`description`,`is_deleted`,`date_added`) values (1,0,1,'asd','asd','asd','asd',3,10,100,200,'f',0,'2015-10-08 21:36:12'),(2,0,2,'Face Wash','435etret435','2234erwerw','F1',4,5,50,70,'',0,'2015-10-08 21:43:10'),(3,1,2,'Cream','1231dd323','12312qewqweqwe','cream1',10,100,30,46,'test',0,'2015-10-08 21:55:31');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
