/*
SQLyog Community Edition- MySQL GUI v7.11 
MySQL - 5.6.17 : Database - nuwax
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`nuwax` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `nuwax`;

/*Table structure for table `action_recorder` */

DROP TABLE IF EXISTS `action_recorder`;

CREATE TABLE `action_recorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `success` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_action_recorder_identifier` (`identifier`),
  KEY `idx_action_recorder_date_added` (`date_added`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `action_recorder` */

insert  into `action_recorder`(`id`,`user_name`,`identifier`,`success`,`date_added`) values (75,'','fe80::f468:a052:a95:248b','0','2015-10-02 12:29:22'),(76,'','fe80::f468:a052:a95:248b','0','2015-10-02 12:29:27'),(77,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 12:29:36'),(78,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 13:08:58'),(79,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 13:24:10'),(80,'admin','192.168.0.4','1','2015-10-02 13:29:26'),(81,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 13:54:26'),(82,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 14:05:49'),(83,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 14:16:25'),(84,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 14:19:39'),(85,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 17:51:47'),(86,'admin','fe80::f468:a052:a95:248b','1','2015-10-02 17:54:31');

/*Table structure for table `admins` */

DROP TABLE IF EXISTS `admins`;

CREATE TABLE `admins` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(50) NOT NULL DEFAULT '',
  `status` enum('super admin','admin') NOT NULL DEFAULT 'admin',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `admins` */

insert  into `admins`(`id`,`username`,`password`,`last_name`,`first_name`,`email`,`status`) values (1,'admin','e10adc3949ba59abbe56e057f20f883e','Admin','Nuwax','admin@nuwax.com','super admin');

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `contactno` varchar(255) DEFAULT NULL,
  `address` text,
  `studentcardno` varchar(255) DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL COMMENT '0=active,1=inactive',
  `remark` text,
  `credit` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(2) DEFAULT NULL COMMENT '0=notdeleted,1=deleted',
  `registerdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

insert  into `customer`(`id`,`name`,`email`,`password`,`contactno`,`address`,`studentcardno`,`status`,`remark`,`credit`,`is_deleted`,`registerdate`) values (1,'test','test@asd.com',NULL,'123','lkj','1',0,'test','8',0,'2015-10-02 20:33:17');

/*Table structure for table `data_log` */

DROP TABLE IF EXISTS `data_log`;

CREATE TABLE `data_log` (
  `logID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `actionDateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `recordID` int(11) NOT NULL,
  `siteSection` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ip` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userLevel` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`logID`)
) ENGINE=InnoDB AUTO_INCREMENT=281 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Data for the table `data_log` */

insert  into `data_log`(`logID`,`userID`,`actionDateTime`,`action`,`recordID`,`siteSection`,`ip`,`userLevel`) values (251,1,'2015-10-02 13:05:15','Edited',1,'Admin Management','fe80::f468:a052:a95:','super admin'),(252,1,'2015-10-02 14:24:39','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(253,1,'2015-10-02 14:25:18','Edited',1,'Admin Management','fe80::f468:a052:a95:','super admin'),(254,1,'2015-10-02 15:44:42','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin'),(255,1,'2015-10-02 16:39:16','Added',1,'Customer Management','fe80::f468:a052:a95:','super admin'),(256,1,'2015-10-02 16:42:39','Added',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(257,1,'2015-10-02 17:15:43','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(258,1,'2015-10-02 17:15:58','Edited',1,'Customer Management','fe80::f468:a052:a95:','super admin'),(259,1,'2015-10-02 17:16:15','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(260,1,'2015-10-02 17:17:03','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(261,1,'2015-10-02 17:17:14','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(262,1,'2015-10-02 17:17:59','Edited',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(263,1,'2015-10-02 17:18:05','Edited',1,'Customer Management','fe80::f468:a052:a95:','super admin'),(264,1,'2015-10-02 17:32:00','Added',3,'Customer Management','fe80::f468:a052:a95:','super admin'),(265,1,'2015-10-02 17:33:44','Added',4,'Customer Management','fe80::f468:a052:a95:','super admin'),(266,1,'2015-10-02 17:38:26','Deleted',3,'Customer Management','fe80::f468:a052:a95:','super admin'),(267,1,'2015-10-02 17:41:29','Edited',4,'Customer Management','fe80::f468:a052:a95:','super admin'),(268,1,'2015-10-02 17:41:38','Deleted',4,'Customer Management','fe80::f468:a052:a95:','super admin'),(269,1,'2015-10-02 17:41:38','Deleted',2,'Customer Management','fe80::f468:a052:a95:','super admin'),(270,1,'2015-10-02 17:41:38','Deleted',1,'Customer Management','fe80::f468:a052:a95:','super admin'),(271,1,'2015-10-02 17:47:55','Changed',4,'Customer Password','fe80::f468:a052:a95:','super admin'),(272,1,'2015-10-02 17:52:28','Added',5,'Customer Management','fe80::f468:a052:a95:','super admin'),(273,1,'2015-10-02 17:52:42','Added',6,'Customer Management','fe80::f468:a052:a95:','super admin'),(274,1,'2015-10-02 17:52:53','Added',7,'Customer Management','fe80::f468:a052:a95:','super admin'),(275,1,'2015-10-02 17:53:06','Added',8,'Customer Management','fe80::f468:a052:a95:','super admin'),(276,1,'2015-10-02 17:53:18','Added',9,'Customer Management','fe80::f468:a052:a95:','super admin'),(277,1,'2015-10-02 17:53:30','Added',10,'Customer Management','fe80::f468:a052:a95:','super admin'),(278,1,'2015-10-02 17:53:41','Added',11,'Customer Management','fe80::f468:a052:a95:','super admin'),(279,1,'2015-10-02 18:03:17','Added',1,'Customer Management','fe80::f468:a052:a95:','super admin'),(280,1,'2015-10-02 18:19:02','Edited',1,'Menu Management','fe80::f468:a052:a95:','super admin');

/*Table structure for table `menu` */

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `page_name` varchar(255) NOT NULL DEFAULT '',
  `is_menu_group` tinyint(1) NOT NULL DEFAULT '0',
  `is_removable` tinyint(1) NOT NULL DEFAULT '0',
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order_index` tinyint(3) NOT NULL DEFAULT '0',
  `icon` varchar(30) DEFAULT NULL,
  `is_dashboard_icon` tinyint(1) DEFAULT '1',
  `is_menu_item` tinyint(1) NOT NULL DEFAULT '1',
  `file_type_id` tinyint(3) NOT NULL DEFAULT '2',
  `access_roles` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'super admin',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `is_menu_name` (`is_menu_group`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `menu` */

insert  into `menu`(`id`,`name`,`page_name`,`is_menu_group`,`is_removable`,`is_hidden`,`parent_id`,`order_index`,`icon`,`is_dashboard_icon`,`is_menu_item`,`file_type_id`,`access_roles`) values (1,'General','',1,0,0,0,0,'general.png',1,1,2,'super admin,Level4'),(2,'Account Manager','',1,0,0,0,1,NULL,1,1,2,'super admin'),(3,'Menu Manager','menu_manager/index.php',0,0,0,1,1,'general.png',1,1,2,'super admin'),(5,'Administrators','admins/index.php',0,0,0,2,0,'admin.png',1,1,2,'super admin'),(10,'Master Forms','',1,0,0,0,2,NULL,1,1,2,'super admin'),(11,'Customers','customers/index',0,0,0,10,1,'xyzer',1,1,2,'super admin'),(12,'Services','services/index',0,0,0,10,2,'xyzer',1,1,2,'super admin'),(14,'Sellers','sellers/index',0,0,0,10,3,'xyzer',1,1,2,'super admin'),(15,'Faqs','faqs/index',0,0,0,10,4,'xyzer',1,1,2,'super admin'),(16,'Category','category/index',0,0,0,10,5,'xyzer',1,1,2,'super admin');

/*Table structure for table `servicecategory` */

DROP TABLE IF EXISTS `servicecategory`;

CREATE TABLE `servicecategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(255) DEFAULT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `remark` text,
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `servicecategory` */

/*Table structure for table `services` */

DROP TABLE IF EXISTS `services`;

CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `servicecatid` int(11) DEFAULT NULL,
  `servicename` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `servicetime` varchar(255) DEFAULT NULL,
  `description` text,
  `taxname` varchar(255) DEFAULT NULL,
  `taxapplicable` int(5) DEFAULT NULL,
  `tax_underpackage` tinyint(2) DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `services` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
