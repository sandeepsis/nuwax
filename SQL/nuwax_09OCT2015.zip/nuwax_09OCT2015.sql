/*
SQLyog Community Edition- MySQL GUI v7.11 
MySQL - 5.6.17 : Database - nuwax
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


USE `nuwax`;

/*Table structure for table `products` */

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoryid` int(11) DEFAULT NULL,
  `productname` varchar(255) DEFAULT NULL,
  `skucode` varchar(255) DEFAULT NULL,
  `barcode` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `volume` int(11) DEFAULT NULL,
  `costprice` int(11) DEFAULT NULL,
  `sellingprice` int(11) DEFAULT NULL,
  `current_stock` int(11) DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL COMMENT '0=for sale, 1=stop selling',
  `description` text,
  `is_deleted` tinyint(2) DEFAULT NULL COMMENT '0=notdelete,1=deleted',
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Table structure for table `stockmanagement` */

DROP TABLE IF EXISTS `stockmanagement`;

CREATE TABLE `stockmanagement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucherno` varchar(255) DEFAULT NULL,
  `productid` int(11) DEFAULT NULL,
  `productquantity` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `emailaddress` varchar(255) DEFAULT NULL,
  `contactno` varchar(255) DEFAULT NULL,
  `voucherdate` datetime DEFAULT NULL,
  `vouchertype` tinyint(2) DEFAULT NULL COMMENT '0=purchase order,1=sales order',
  `remark` text,
  `date_added` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
